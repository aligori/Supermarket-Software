package model;

public interface Checker {
    boolean checkUser(String username, String password);
}
