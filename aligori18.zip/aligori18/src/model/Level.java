package model;

public enum Level {
    ADMIN,ECONOMIST,CASHIER;
}
